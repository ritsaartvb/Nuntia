window.onload = function() {
    document.getElementById('greeting').textContent = "NUNTIA";
  
    document.getElementById('icon').addEventListener('click', function() {
      print("left 5; right 4");
    });
  }
  